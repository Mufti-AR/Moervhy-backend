
from flask import Flask, request, jsonify
import openai
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/generate", methods=["POST"])
def generate_prompt():
    data = request.get_json()
    language = data.get("language", "id")
    category = data.get("category", "random")

    prompt_text = f"Buatkan 1 prompt kreatif untuk video Veo 3 kategori '{category}' dalam bahasa {'Indonesia' if language == 'id' else 'English'} yang lucu, absurd, atau menarik."

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Kamu adalah generator prompt kreatif untuk video AI Veo 3."},
                {"role": "user", "content": prompt_text}
            ],
            temperature=0.9,
            max_tokens=200
        )
        prompt = response.choices[0].message["content"].strip()
        return jsonify({"prompt": prompt})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
