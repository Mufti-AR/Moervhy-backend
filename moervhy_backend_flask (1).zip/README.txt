
# Moervhy Prompt Generator - Backend Flask

## 🔧 Replit Setup

1. Upload semua file ini ke Replit (gunakan template Python atau Flask).
2. Tambahkan Secret:
   - Buka tab 🔐 Secrets (Environment Variables)
   - Nama: `OPENAI_API_KEY`
   - Value: API key dari OpenAI kamu

3. Jalankan file `main.py`
4. Copy URL Replit kamu dan tempel ke `index.html` bagian fetch:

```js
fetch('https://your-url.repl.co/generate', {...})
```

Selesai!
